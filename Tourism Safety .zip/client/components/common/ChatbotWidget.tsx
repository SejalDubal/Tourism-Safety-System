import { useState, useRef, useEffect } from "react";
import { MessageCircle, Send } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ChatbotWidget() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    { role: "bot", content: "Hi! I’m your AI travel assistant. Ask about places, safety, or bookings." },
  ] as { role: "bot" | "user"; content: string }[]);
  const [input, setInput] = useState("");
  const endRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, open]);

  function send() {
    if (!input.trim()) return;
    const user = { role: "user" as const, content: input.trim() };
    setMessages((m) => [...m, user]);
    setInput("");
    // Mock bot reply
    setTimeout(() => {
      setMessages((m) => [
        ...m,
        {
          role: "bot",
          content:
            "I’ll help you plan a safe, enjoyable trip. Try: ‘Find forts near Pune’, ‘Book slot for Saturday 10am’, or ‘Show verified guides’.",
        },
      ]);
    }, 500);
  }

  return (
    <div className="fixed bottom-4 right-4 z-50">
      {open && (
        <div className="mb-3 w-[90vw] max-w-sm rounded-xl border bg-background shadow-xl">
          <div className="flex items-center justify-between px-4 py-3 border-b">
            <div className="font-semibold">AI Travel Assistant</div>
            <button onClick={() => setOpen(false)} className="text-sm text-muted-foreground hover:underline">Close</button>
          </div>
          <div className="max-h-80 overflow-y-auto p-4 space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={m.role === "user" ? "text-right" : "text-left"}>
                <div className={
                  m.role === "user"
                    ? "inline-block rounded-lg bg-brand-ocean text-white px-3 py-2"
                    : "inline-block rounded-lg bg-secondary px-3 py-2"
                }>
                  {m.content}
                </div>
              </div>
            ))}
            <div ref={endRef} />
          </div>
          <div className="flex items-center gap-2 p-3 border-t">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              placeholder="Ask about places, safety, bookings..."
              className="flex-1 rounded-md border px-3 py-2 text-sm bg-background"
            />
            <Button onClick={send} className="bg-brand-mint hover:bg-brand-mint/90">
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
      <Button onClick={() => setOpen((v) => !v)} size="lg" className="h-14 w-14 rounded-full shadow-lg bg-gradient-to-br from-brand-ocean to-brand-sunset">
        <MessageCircle className="h-6 w-6 text-white" />
      </Button>
    </div>
  );
}

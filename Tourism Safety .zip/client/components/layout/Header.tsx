import { Link, NavLink, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Compass, ShieldCheck, CalendarClock } from "lucide-react";

export default function Header() {
  const { pathname } = useLocation();
  const links = [
    { to: "/", label: "Home" },
    { to: "/booking", label: "Slot Booking" },
    { to: "/guides", label: "Guides" },
    { to: "/planner", label: "Trip Planner" },
    { to: "/blogs", label: "Blogs" },
    { to: "/dashboard", label: "Authority" },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/80 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-brand-ocean to-brand-sunset grid place-items-center text-white">
            <Compass className="h-5 w-5" />
          </div>
          <div className="leading-tight">
            <div className="font-extrabold text-lg tracking-tight">SafeTrip</div>
            <div className="text-xs text-muted-foreground -mt-1">Tourist Safety & Planner</div>
          </div>
        </Link>
        <nav className="hidden md:flex items-center gap-2">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                cn(
                  "rounded-md px-3 py-2 text-sm font-medium text-muted-foreground hover:text-foreground",
                  isActive && "text-foreground bg-secondary"
                )
              }
              end={l.to === "/"}
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Button asChild className="bg-brand-ocean text-white hover:bg-brand-ocean/90 hidden md:inline-flex">
            <Link to="/auth">Get Started</Link>
          </Button>
          {pathname !== "/booking" && (
            <Button
              asChild
              className="hidden sm:inline-flex text-white"
              style={{ backgroundColor: "rgba(126, 211, 33, 1)" }}
            >
              <Link to="/booking">
                <CalendarClock className="h-4 w-4" /> Book Slot
              </Link>
            </Button>
          )}
          <Button
            variant="outline"
            className="inline-flex gap-2 bg-white"
            style={{ border: "0.8px solid rgba(74, 144, 226, 1)", color: "#0D80F2" }}
          >
            <ShieldCheck className="h-4 w-4" style={{ color: "#0D80F2" }} />
            Safety
          </Button>
        </div>
      </div>
      <div className="md:hidden border-t">
        <div className="container py-2 flex flex-wrap gap-2">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                cn(
                  "rounded-md px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground",
                  isActive && "text-foreground bg-secondary"
                )
              }
              end={l.to === "/"}
            >
              {l.label}
            </NavLink>
          ))}
        </div>
      </div>
    </header>
  );
}

export default function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-8 grid gap-4 md:grid-cols-3 items-center">
        <p className="text-sm text-muted-foreground">© {new Date().getFullYear()} SafeTrip. All rights reserved.</p>
        <p className="text-sm text-muted-foreground md:text-center">Made for safer, smarter journeys.</p>
        <div className="md:justify-end flex gap-3">
          <a href="#" className="text-sm hover:underline">Privacy</a>
          <a href="#" className="text-sm hover:underline">Terms</a>
          <a href="#" className="text-sm hover:underline">Contact</a>
        </div>
      </div>
    </footer>
  );
}

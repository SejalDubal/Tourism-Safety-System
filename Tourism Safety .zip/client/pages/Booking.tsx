import { useMemo, useState } from "react";
import {
  addDays,
  eachDayOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  isBefore,
  isSameDay,
  isSameMonth,
  isToday,
  startOfMonth,
  startOfWeek,
  subMonths,
  addMonths,
} from "date-fns";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Calendar, Clock } from "lucide-react";

const allSlots = [
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "14:00",
  "15:00",
  "16:00",
  "17:00",
];

function availableSlots(d: Date) {
  // Simple availability logic: fewer slots on weekends
  const day = d.getDay();
  if (day === 0) return allSlots.filter((_, i) => i % 2 === 0);
  if (day === 6) return allSlots.filter((_, i) => i !== 3);
  return allSlots;
}

export default function Booking() {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(new Date());
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);

  const days = useMemo(() => {
    const start = startOfWeek(startOfMonth(currentMonth), { weekStartsOn: 1 });
    const end = endOfWeek(endOfMonth(currentMonth), { weekStartsOn: 1 });
    return eachDayOfInterval({ start, end });
  }, [currentMonth]);

  const slots = selectedDate ? availableSlots(selectedDate) : [];

  function book() {
    if (!selectedDate || !selectedSlot) return;
    toast.success(
      `Booked ${format(selectedDate, "PPPP")} at ${selectedSlot} successfully!`,
    );
  }

  return (
    <section className="container py-12">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">Slot Booking</h1>
        <p className="mt-3 text-muted-foreground">
          Reserve entry times for forts and heritage sites. Real-time availability, instant confirmation.
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Calendar className="h-5 w-5 text-brand-ocean"/> Select Date</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-4">
              <Button variant="outline" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
                {format(subMonths(currentMonth, 1), "MMM yyyy")}
              </Button>
              <div className="font-semibold">{format(currentMonth, "MMMM yyyy")}</div>
              <Button variant="outline" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
                {format(addMonths(currentMonth, 1), "MMM yyyy")}
              </Button>
            </div>
            <div className="grid grid-cols-7 text-center text-xs text-muted-foreground">
              {"MTWTFSS".split("").map((d) => (
                <div key={d} className="py-2">{d}</div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-2">
              {days.map((day) => {
                const disabled = isBefore(day, new Date()) && !isToday(day);
                const isCurrent = selectedDate && isSameDay(day, selectedDate);
                return (
                  <button
                    key={day.toString()}
                    onClick={() => !disabled && setSelectedDate(day)}
                    className={
                      "aspect-square rounded-md border text-sm " +
                      (disabled
                        ? "opacity-40 cursor-not-allowed"
                        : isCurrent
                        ? "bg-brand-ocean text-white"
                        : isSameMonth(day, currentMonth)
                        ? "hover:bg-secondary"
                        : "text-muted-foreground hover:bg-secondary")
                    }
                  >
                    <div className="flex h-full items-center justify-center">
                      {format(day, "d")}
                    </div>
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Clock className="h-5 w-5 text-brand-sunset"/> Select Time Slot</CardTitle>
          </CardHeader>
          <CardContent>
            {selectedDate ? (
              <>
                <p className="mb-3 text-sm text-muted-foreground">{format(selectedDate, "PPPP")}</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {slots.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSelectedSlot(s)}
                      className={
                        "rounded-md border px-3 py-2 text-sm hover:bg-secondary " +
                        (selectedSlot === s ? "bg-brand-mint text-white border-transparent" : "")
                      }
                    >
                      {s}
                    </button>
                  ))}
                </div>
                <div className="mt-6 flex gap-3">
                  <Button onClick={book} disabled={!selectedDate || !selectedSlot} className="bg-brand-ocean text-white hover:bg-brand-ocean/90">
                    Book Slot
                  </Button>
                  <Button variant="outline" onClick={() => setSelectedSlot(null)}>Clear</Button>
                </div>
              </>
            ) : (
              <p className="text-muted-foreground">Select a date to see available slots.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </section>
  );
}

import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { BellRing, ShieldAlert, MapPin, Phone, CheckCircle2, Clock, Filter } from "lucide-react";

type Sos = {
  id: string;
  name: string;
  phone: string;
  location: string;
  time: string; // ISO or display
  status: "sent" | "acknowledged" | "resolved";
};

const DUMMY_SOS: Sos[] = [
  { id: "s1", name: "Priya Shah", phone: "+91 98765 11001", location: "Sinhagad Fort Base", time: "2025-03-10T09:42:00Z", status: "acknowledged" },
  { id: "s2", name: "Arjun Mehta", phone: "+91 98989 22002", location: "Rajgad Trail Point 3", time: "2025-03-10T08:55:00Z", status: "sent" },
  { id: "s3", name: "Neha Verma", phone: "+91 99100 33003", location: "Torna Fort Parking", time: "2025-03-10T07:30:00Z", status: "resolved" },
  { id: "s4", name: "Ravi Kumar", phone: "+91 99220 44004", location: "Khadakwasla Lake", time: "2025-03-09T18:21:00Z", status: "acknowledged" },
  { id: "s5", name: "Sara Ali", phone: "+91 99550 55005", location: "Shaniwar Wada", time: "2025-03-09T15:07:00Z", status: "resolved" },
];

function fmtDate(d: string) {
  const date = new Date(d);
  return date.toLocaleString();
}

function StatusBadge({ s }: { s: Sos["status"] }) {
  const map = {
    sent: { label: "Sent", className: "bg-brand-sunset text-white border-transparent" },
    acknowledged: { label: "Acknowledged", className: "bg-brand-mint text-white border-transparent" },
    resolved: { label: "Resolved", className: "bg-brand-ocean text-white border-transparent" },
  } as const;
  const v = map[s];
  return <Badge className={"px-2.5 py-0.5 " + v.className}>{v.label}</Badge>;
}

export default function Dashboard() {
  const total = DUMMY_SOS.length;
  const active = DUMMY_SOS.filter((s) => s.status !== "resolved").length;
  const resolved = DUMMY_SOS.filter((s) => s.status === "resolved").length;

  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<"all" | Sos["status"]>("all");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return DUMMY_SOS.filter((s) => {
      const matchQ = !q || s.name.toLowerCase().includes(q) || s.location.toLowerCase().includes(q) || s.phone.replace(/\s|\+/g, "").includes(q.replace(/\s|\+/g, ""));
      const matchS = status === "all" || s.status === status;
      return matchQ && matchS;
    });
  }, [query, status]);

  return (
    <section className="container py-12">
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">Authority Dashboard</h1>
        <p className="mt-3 text-muted-foreground">SOS alerts overview, status tracking, and quick actions.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="flex items-center gap-2"><BellRing className="h-5 w-5 text-brand-sunset"/> Total SOS Alerts</CardTitle></CardHeader>
          <CardContent>
            <div className="text-4xl font-extrabold">{total}</div>
            <p className="text-sm text-muted-foreground">All-time</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="flex items-center gap-2"><ShieldAlert className="h-5 w-5 text-brand-ocean"/> Active</CardTitle></CardHeader>
          <CardContent>
            <div className="text-4xl font-extrabold">{active}</div>
            <p className="text-sm text-muted-foreground">Sent or acknowledged</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="flex items-center gap-2"><CheckCircle2 className="h-5 w-5 text-brand-mint"/> Resolved</CardTitle></CardHeader>
          <CardContent>
            <div className="text-4xl font-extrabold">{resolved}</div>
            <p className="text-sm text-muted-foreground">Closed incidents</p>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        {/* Left: Recent SOS list */}
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle>Recent SOS Alerts</CardTitle>
            <CardDescription>Search and filter by status.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <Input placeholder="Search by name, phone, or location" value={query} onChange={(e) => setQuery(e.target.value)} />
              <div className="flex items-center gap-2">
                <Filter className="h-4 w-4 text-muted-foreground" />
                <select
                  className="h-10 rounded-md border bg-background px-3 text-sm"
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                >
                  <option value="all">All</option>
                  <option value="sent">Sent</option>
                  <option value="acknowledged">Acknowledged</option>
                  <option value="resolved">Resolved</option>
                </select>
              </div>
              <Button variant="outline" onClick={() => { setQuery(""); setStatus("all"); }}>Clear</Button>
            </div>

            <div className="mt-4 divide-y">
              {filtered.map((s) => (
                <div key={s.id} className="grid grid-cols-1 gap-3 py-3 sm:grid-cols-5 sm:items-center">
                  <div className="sm:col-span-2">
                    <div className="font-medium">{s.name}</div>
                    <div className="mt-0.5 text-xs text-muted-foreground inline-flex items-center gap-1"><MapPin className="h-3 w-3"/> {s.location}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4 text-brand-ocean" />
                    <a href={`tel:${s.phone.replace(/\s|\+/g, "")}`} className="text-sm hover:underline">{s.phone}</a>
                  </div>
                  <div className="text-sm inline-flex items-center gap-1"><Clock className="h-4 w-4 text-muted-foreground"/>{fmtDate(s.time)}</div>
                  <div className="flex items-center justify-between sm:justify-end gap-3">
                    <StatusBadge s={s.status} />
                    <Button size="sm" variant="outline">View</Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Right: Map + quick actions */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle>Alerts Heatmap</CardTitle>
            <CardDescription>Today’s distribution (demo)</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-square rounded-lg bg-gradient-to-br from-brand-ocean/10 via-brand-mint/10 to-brand-sunset/10 p-1">
              <div className="relative h-full w-full rounded-md bg-background">
                <svg viewBox="0 0 100 100" className="absolute inset-0 h-full w-full">
                  <defs>
                    <radialGradient id="hot" cx="50%" cy="50%">
                      <stop offset="0%" stopColor="hsl(var(--brand-sunset))" stopOpacity="0.8" />
                      <stop offset="100%" stopColor="hsl(var(--brand-sunset))" stopOpacity="0" />
                    </radialGradient>
                  </defs>
                  <circle cx="30" cy="34" r="14" fill="url(#hot)" />
                  <circle cx="62" cy="46" r="11" fill="url(#hot)" />
                  <circle cx="48" cy="68" r="9" fill="url(#hot)" />
                </svg>
                <div className="absolute bottom-2 left-2 rounded-md border bg-background/80 px-2 py-1 text-xs">Demo heat zones</div>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex items-center gap-2">
            <Button className="w-full">Acknowledge All</Button>
            <Button variant="outline" className="w-full">Export</Button>
          </CardFooter>
        </Card>
      </div>
    </section>
  );
}

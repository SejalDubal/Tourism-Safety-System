import { Link } from "react-router-dom";
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

type Post = {
  id: string;
  title: string;
  excerpt: string;
  tag: string;
  date: string;
  color: "ocean" | "mint" | "sunset";
};

const POSTS: Post[] = [
  {
    id: "b1",
    title: "Exploring Rajgad: The King of Forts",
    excerpt: "History, best routes, and safety tips for a perfect trek to Rajgad Fort.",
    tag: "Forts",
    date: "Mar 5, 2025",
    color: "ocean",
  },
  {
    id: "b2",
    title: "Local Cuisine: A Foodie’s Guide to Pune",
    excerpt: "From FC Road snacks to authentic thalis—what not to miss.",
    tag: "Culture",
    date: "Mar 2, 2025",
    color: "sunset",
  },
  {
    id: "b3",
    title: "Understanding Fort Etiquette",
    excerpt: "Respecting heritage sites while ensuring your safety and the environment’s.",
    tag: "Safety",
    date: "Feb 22, 2025",
    color: "mint",
  },
  {
    id: "b4",
    title: "Weekend Itinerary: Sinhagad + Khadakwasla",
    excerpt: "A quick, scenic plan with timings, parking, and crowd hacks.",
    tag: "Itinerary",
    date: "Feb 18, 2025",
    color: "ocean",
  },
  {
    id: "b5",
    title: "Top 5 Heritage Spots in Pune",
    excerpt: "Shortlist with travel time, best hours to visit, and entry details.",
    tag: "Heritage",
    date: "Feb 9, 2025",
    color: "mint",
  },
  {
    id: "b6",
    title: "Monsoon Trek Safety Checklist",
    excerpt: "Gear, weather checks, and dos/don’ts before you start.",
    tag: "Safety",
    date: "Jan 31, 2025",
    color: "sunset",
  },
];

function Thumb({ color }: { color: Post["color"] }) {
  const grad =
    color === "ocean"
      ? "from-brand-ocean to-brand-mint"
      : color === "mint"
      ? "from-brand-mint to-brand-ocean"
      : "from-brand-sunset to-brand-mint";
  return (
    <div className={`aspect-[16/9] w-full rounded-md bg-gradient-to-br ${grad} p-0.5`}> 
      <div className="h-full w-full rounded-[6px] bg-background grid place-items-center text-sm text-muted-foreground">
        Featured
      </div>
    </div>
  );
}

export default function Blogs() {
  return (
    <section className="container py-12">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">Blogs</h1>
        <p className="mt-4 text-muted-foreground">Stories on forts, local culture, history, safety, and itineraries.</p>
      </div>

      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {POSTS.map((p) => (
          <Card key={p.id} className="flex flex-col">
            <CardHeader className="pb-3">
              <Thumb color={p.color} />
              <div className="mt-3 flex items-center justify-between">
                <Badge variant="secondary">{p.tag}</Badge>
                <span className="text-xs text-muted-foreground">{p.date}</span>
              </div>
              <CardTitle className="mt-2 text-xl leading-snug">{p.title}</CardTitle>
              <CardDescription className="mt-1">{p.excerpt}</CardDescription>
            </CardHeader>
            <CardContent className="pt-0" />
            <CardFooter className="mt-auto">
              <Button asChild className="w-full">
                <Link to="#">Read more</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </section>
  );
}

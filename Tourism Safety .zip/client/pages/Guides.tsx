import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ShieldCheck, Star, Phone } from "lucide-react";

type Guide = {
  id: string;
  name: string;
  phone: string;
  languages: string[];
  rating: number; // 0-5
  reviews: number;
  verified: boolean;
  city: string;
};

const DUMMY_GUIDES: Guide[] = [
  {
    id: "g1",
    name: "Aarav Kulkarni",
    phone: "+91 98765 43210",
    languages: ["English", "Marathi", "Hindi"],
    rating: 4.8,
    reviews: 124,
    verified: true,
    city: "Pune",
  },
  {
    id: "g2",
    name: "Mira Deshpande",
    phone: "+91 99876 54321",
    languages: ["English", "Hindi"],
    rating: 4.6,
    reviews: 98,
    verified: true,
    city: "Mumbai",
  },
  {
    id: "g3",
    name: "Rohan Patil",
    phone: "+91 91234 56780",
    languages: ["Marathi", "Hindi"],
    rating: 4.2,
    reviews: 76,
    verified: true,
    city: "Satara",
  },
  {
    id: "g4",
    name: "Sara Khan",
    phone: "+91 90123 45678",
    languages: ["English", "Urdu", "Hindi"],
    rating: 4.9,
    reviews: 210,
    verified: true,
    city: "Aurangabad",
  },
  {
    id: "g5",
    name: "Vikram Joshi",
    phone: "+91 90909 80808",
    languages: ["English", "Marathi"],
    rating: 4.4,
    reviews: 65,
    verified: true,
    city: "Nashik",
  },
  {
    id: "g6",
    name: "Ananya Rao",
    phone: "+91 98012 34567",
    languages: ["English", "Kannada", "Hindi"],
    rating: 4.7,
    reviews: 142,
    verified: true,
    city: "Belagavi",
  },
];

function Stars({ value }: { value: number }) {
  const full = Math.floor(value);
  const half = value - full >= 0.5;
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: 5 }).map((_, i) => {
        const active = i < full || (half && i === full);
        return (
          <Star
            key={i}
            className={active ? "text-brand-sunset" : "text-muted-foreground"}
            fill={active ? "currentColor" : "none"}
            strokeWidth={2}
            size={16}
          />
        );
      })}
    </div>
  );
}

export default function Guides() {
  const [query, setQuery] = useState("");
  const [minRating, setMinRating] = useState(0);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return DUMMY_GUIDES.filter((g) => {
      const matchesQuery = !q
        || g.name.toLowerCase().includes(q)
        || g.languages.join(",").toLowerCase().includes(q)
        || g.city.toLowerCase().includes(q)
        || g.phone.replace(/\s|\+/g, "").includes(q.replace(/\s|\+/g, ""));
      const matchesRating = g.rating >= minRating;
      return matchesQuery && matchesRating;
    });
  }, [query, minRating]);

  return (
    <section className="container py-12">
      <div className="mx-auto max-w-3xl text-center">
        <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">Guide Directory</h1>
        <p className="mt-4 text-muted-foreground">
          Verified local experts with digital ID badges. Search by name, city, or language.
        </p>
      </div>

      <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <div className="sm:col-span-2 lg:col-span-2 flex gap-3">
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by name, city, or language"
          />
          <Button variant="outline" onClick={() => { setQuery(""); setMinRating(0); }}>Clear</Button>
        </div>
        <div className="flex items-center gap-2">
          <label htmlFor="rating" className="text-sm text-muted-foreground">Min rating</label>
          <select
            id="rating"
            className="h-10 rounded-md border bg-background px-3 text-sm"
            value={minRating}
            onChange={(e) => setMinRating(Number(e.target.value))}
          >
            {[0, 3, 3.5, 4, 4.5].map((r) => (
              <option key={r} value={r}>{r === 0 ? "Any" : `${r}+`}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((g) => (
          <Card key={g.id} className="relative overflow-hidden">
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <CardTitle className="text-xl">{g.name}</CardTitle>
                  <CardDescription className="mt-1">{g.city} · {g.languages.join(", ")}</CardDescription>
                </div>
                {g.verified && (
                  <Badge className="flex items-center gap-1 bg-brand-mint text-white border-transparent">
                    <ShieldCheck className="h-3.5 w-3.5" /> Verified
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Stars value={g.rating} />
                  <span className="text-sm font-medium">{g.rating.toFixed(1)}</span>
                  <span className="text-xs text-muted-foreground">({g.reviews} reviews)</span>
                </div>
              </div>
              <div className="mt-4 flex items-center gap-2 text-sm">
                <Phone className="h-4 w-4 text-brand-ocean" />
                <a href={`tel:${g.phone.replace(/\s|\+/g, "")}`} className="hover:underline">{g.phone}</a>
              </div>
              <div className="mt-4">
                <Button variant="outline" className="w-full">Contact Guide</Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {filtered.length === 0 && (
          <div className="col-span-full text-center text-muted-foreground">No guides match your search.</div>
        )}
      </div>
    </section>
  );
}

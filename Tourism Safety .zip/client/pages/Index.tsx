import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { ShieldCheck, CalendarClock, Users, MapPin } from "lucide-react";

export default function Index() {
  return (
    <>
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-gradient-to-br from-brand-ocean/10 via-brand-mint/10 to-brand-sunset/10" />
        <div className="container py-16 sm:py-24">
          <div className="grid gap-10 lg:grid-cols-2 lg:items-center">
            <div>
              <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight leading-tight">
                Smart Tourist Safety & Trip Planner
              </h1>
              <p className="mt-4 text-lg text-muted-foreground">
                Plan safer, smarter journeys. Real-time safety alerts, verified guides, and easy slot bookings.
              </p>
              <div className="mt-6 flex w-full max-w-xl items-center gap-3">
                <Input placeholder="Search places, forts, heritage sites" />
                <Button className="bg-brand-ocean text-white hover:bg-brand-ocean/90">Search</Button>
              </div>
              <div className="mt-6 flex flex-wrap gap-3 text-sm">
                <span className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1"><ShieldCheck className="h-4 w-4 text-brand-ocean"/> Safety First</span>
                <span className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1"><CalendarClock className="h-4 w-4 text-brand-sunset"/> Slot Booking</span>
                <span className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1"><Users className="h-4 w-4 text-brand-mint"/> Verified Guides</span>
              </div>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button
                  asChild
                  className="text-white"
                  style={{ backgroundColor: "rgba(126, 211, 33, 1)" }}
                >
                  <Link to="/auth">Get Started</Link>
                </Button>
                <Button asChild>
                  <Link to="/booking">Book a Slot</Link>
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-video rounded-2xl bg-gradient-to-br from-brand-ocean to-brand-sunset p-1 shadow-xl">
                <div className="h-full w-full rounded-2xl bg-background relative overflow-hidden">
                  <svg
                    viewBox="0 0 800 450"
                    className="absolute inset-0 h-full w-full"
                    style={{
                      backgroundImage:
                        'url("https://cdn.builder.io/api/v1/image/assets%2F05cc3dc6f5b1458db5179eff5fea6e92%2F5b9b2b9f23dc42438c96bc668d5a15d8")',
                      backgroundRepeat: "no-repeat",
                      backgroundPosition: "center",
                      backgroundSize: "cover",
                    }}
                  >
                    <defs>
                      <linearGradient id="gradMap" x1="0" y1="0" x2="1" y2="1">
                        <stop offset="0%" stopColor="hsl(var(--brand-ocean))" stopOpacity="0.12" />
                        <stop offset="100%" stopColor="hsl(var(--brand-mint))" stopOpacity="0.15" />
                      </linearGradient>
                      <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                        <path d="M 40 0 L 0 0 0 40" fill="none" stroke="hsl(var(--border))" strokeWidth="0.5" opacity="0.4" />
                      </pattern>
                    </defs>
                    <rect width="800" height="450" fill="url(#grid)" />
                    <g>
                      <path d="M80 360 C 180 280, 260 300, 340 250 S 520 170, 700 220" fill="none" stroke="hsl(var(--brand-mint))" strokeWidth="4" strokeLinecap="round" strokeDasharray="6 8" />
                      <circle cx="120" cy="340" r="8" fill="hsl(var(--brand-sunset))" />
                      <circle cx="250" cy="290" r="8" fill="hsl(var(--brand-ocean))" />
                      <circle cx="380" cy="240" r="8" fill="hsl(var(--brand-sunset))" />
                      <circle cx="520" cy="190" r="8" fill="hsl(var(--brand-ocean))" />
                      <circle cx="680" cy="220" r="8" fill="hsl(var(--brand-sunset))" />
                    </g>
                    <path d="M40 40 H760 V410 H40 Z" fill="url(#gradMap)" />
                  </svg>
                  <div className="absolute top-4 left-4 rounded-lg border bg-background backdrop-blur px-3 py-2 shadow">
                    <div className="flex items-center gap-2 text-sm font-medium"><MapPin className="h-4 w-4 text-brand-ocean"/> Nearby Forts</div>
                    <div className="text-xs text-muted-foreground">12 attractions within 25 km</div>
                  </div>
                  <div className="absolute bottom-4 left-4 rounded-lg border bg-background backdrop-blur px-3 py-2 shadow">
                    <div className="text-sm font-medium">Itinerary Preview</div>
                    <div className="text-xs text-muted-foreground">Day 1: Rajgad → Torna → Sinhagad</div>
                  </div>
                  <div className="absolute top-4 right-4 rounded-lg bg-brand-ocean text-white px-3 py-2 shadow text-sm">Safe Route</div>
                </div>
              </div>
              <div className="absolute -bottom-4 -right-4 hidden sm:block rounded-xl border bg-background px-4 py-3 shadow-lg">
                <div className="text-sm font-medium">Live Safety Index</div>
                <div className="text-xs text-muted-foreground">All clear · No alerts nearby</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="container py-12">
        <div className="grid gap-6 md:grid-cols-3">
          <Card>
            <CardContent className="p-6">
              <ShieldCheck className="h-8 w-8 text-brand-ocean" />
              <h3 className="mt-4 text-xl font-semibold">Real-time Safety</h3>
              <p className="mt-2 text-sm text-muted-foreground">Get instant alerts, SOS assistance, and safe route suggestions.</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <CalendarClock className="h-8 w-8 text-brand-sunset" />
              <h3 className="mt-4 text-xl font-semibold">Easy Slot Booking</h3>
              <p className="mt-2 text-sm text-muted-foreground">Reserve entry for forts and heritage sites with a few taps.</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <Users className="h-8 w-8 text-brand-mint" />
              <h3 className="mt-4 text-xl font-semibold">Verified Guides</h3>
              <p className="mt-2 text-sm text-muted-foreground">Browse trusted guides with digital ID badges and ratings.</p>
            </CardContent>
          </Card>
        </div>
      </section>
    </>
  );
}

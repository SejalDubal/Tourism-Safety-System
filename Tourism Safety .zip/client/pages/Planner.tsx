import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock, ShieldCheck, Trash2, ChevronUp, ChevronDown, Wand2 } from "lucide-react";
import { toast } from "sonner";

type Place = {
  id: string;
  name: string;
  type: "fort" | "heritage" | "scenic" | "food" | "museum";
  distanceKm: number;
  durationMin: number;
  safetyScore: number; // 0-100
  rating: number; // 0-5
  coord: { x: number; y: number }; // 0..100 for SVG positioning
};

const PLACES: Place[] = [
  { id: "p1", name: "Rajgad Fort", type: "fort", distanceKm: 22, durationMin: 45, safetyScore: 92, rating: 4.7, coord: { x: 15, y: 70 } },
  { id: "p2", name: "Sinhagad Fort", type: "fort", distanceKm: 28, durationMin: 55, safetyScore: 90, rating: 4.6, coord: { x: 35, y: 62 } },
  { id: "p3", name: "Torna Fort", type: "fort", distanceKm: 38, durationMin: 75, safetyScore: 88, rating: 4.5, coord: { x: 55, y: 50 } },
  { id: "p4", name: "Aga Khan Palace", type: "heritage", distanceKm: 12, durationMin: 25, safetyScore: 95, rating: 4.4, coord: { x: 70, y: 40 } },
  { id: "p5", name: "Shaniwar Wada", type: "heritage", distanceKm: 9, durationMin: 18, safetyScore: 94, rating: 4.3, coord: { x: 62, y: 30 } },
  { id: "p6", name: "Khadakwasla Lake", type: "scenic", distanceKm: 18, durationMin: 35, safetyScore: 97, rating: 4.6, coord: { x: 42, y: 38 } },
  { id: "p7", name: "Pataleshwar Caves", type: "heritage", distanceKm: 8, durationMin: 16, safetyScore: 93, rating: 4.2, coord: { x: 58, y: 24 } },
  { id: "p8", name: "FC Road Food Street", type: "food", distanceKm: 10, durationMin: 20, safetyScore: 89, rating: 4.1, coord: { x: 50, y: 20 } },
  { id: "p9", name: "Kelkar Museum", type: "museum", distanceKm: 11, durationMin: 22, safetyScore: 92, rating: 4.3, coord: { x: 66, y: 22 } },
];

const TYPE_LABEL: Record<Place["type"], string> = {
  fort: "Fort",
  heritage: "Heritage",
  scenic: "Scenic",
  food: "Food",
  museum: "Museum",
};

function useFilteredPlaces(q: string, activeTypes: Set<Place["type"]>) {
  const lower = q.trim().toLowerCase();
  return useMemo(
    () =>
      PLACES.filter((p) =>
        (!lower || p.name.toLowerCase().includes(lower)) &&
        (activeTypes.size === 0 || activeTypes.has(p.type))
      ).sort((a, b) => a.distanceKm - b.distanceKm),
    [lower, activeTypes],
  );
}

type DayPlan = { id: number; items: Place[] };

export default function Planner() {
  const [query, setQuery] = useState("");
  const [activeTypes, setActiveTypes] = useState<Set<Place["type"]>>(new Set());
  const [dayIndex, setDayIndex] = useState(0);
  const [plans, setPlans] = useState<DayPlan[]>([
    { id: 1, items: [] },
    { id: 2, items: [] },
    { id: 3, items: [] },
  ]);

  const places = useFilteredPlaces(query, activeTypes);
  const current = plans[dayIndex];

  function toggleType(t: Place["type"]) {
    setActiveTypes((prev) => {
      const n = new Set(prev);
      if (n.has(t)) n.delete(t);
      else n.add(t);
      return n;
    });
  }

  function addToDay(p: Place) {
    setPlans((prev) => {
      const copy = [...prev];
      const items = copy[dayIndex].items;
      if (!items.find((i) => i.id === p.id)) {
        items.push(p);
        toast.success(`Added ${p.name} to Day ${copy[dayIndex].id}`);
      }
      return copy;
    });
  }

  function removeFromDay(i: number) {
    setPlans((prev) => {
      const copy = [...prev];
      const removed = copy[dayIndex].items.splice(i, 1)[0];
      if (removed) toast.message(`Removed ${removed.name}`);
      return copy;
    });
  }

  function move(idx: number, dir: -1 | 1) {
    setPlans((prev) => {
      const copy = [...prev];
      const arr = copy[dayIndex].items;
      const j = idx + dir;
      if (j < 0 || j >= arr.length) return copy;
      [arr[idx], arr[j]] = [arr[j], arr[idx]];
      return copy;
    });
  }

  function optimize() {
    setPlans((prev) => {
      const copy = [...prev];
      const arr = [...copy[dayIndex].items];
      if (arr.length <= 2) {
        toast.info("Need at least 3 places to optimize route");
        return copy;
      }
      // Nearest-neighbor heuristic from first item
      const result: Place[] = [arr[0]];
      const rest = arr.slice(1);
      while (rest.length) {
        const last = result[result.length - 1];
        let bestIdx = 0;
        let bestDist = Infinity;
        for (let i = 0; i < rest.length; i++) {
          const d = dist(last.coord, rest[i].coord);
          if (d < bestDist) {
            bestDist = d;
            bestIdx = i;
          }
        }
        result.push(rest.splice(bestIdx, 1)[0]!);
      }
      copy[dayIndex].items = result;
      toast.success("Optimized route order");
      return copy;
    });
  }

  function clearDay() {
    setPlans((prev) => {
      const copy = [...prev];
      copy[dayIndex].items = [];
      return copy;
    });
  }

  return (
    <section className="container py-12">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">Trip Planner</h1>
        <p className="mt-3 text-muted-foreground">Find nearby attractions and build a day-wise itinerary. Get smart suggestions and a safe route.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2 lg:items-start">
        {/* Left: Nearby places & suggestions */}
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2"><MapPin className="h-5 w-5 text-brand-ocean"/> Nearby Places</CardTitle>
              <CardDescription>Search and filter by type, sorted by distance.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                <Input placeholder="Search forts, heritage, food…" value={query} onChange={(e) => setQuery(e.target.value)} />
                <Button variant="outline" onClick={() => { setQuery(""); setActiveTypes(new Set()); }}>Clear</Button>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                {(["fort","heritage","scenic","food","museum"] as Place["type"][]).map((t) => (
                  <button
                    key={t}
                    onClick={() => toggleType(t)}
                    className={(activeTypes.has(t)?"bg-brand-mint text-white border-transparent":"bg-secondary")+" rounded-full border px-3 py-1 text-xs font-medium capitalize"}
                  >
                    {TYPE_LABEL[t]}
                  </button>
                ))}
              </div>

              <div className="mt-6 space-y-3">
                {places.map((p) => (
                  <div key={p.id} className="flex items-center justify-between rounded-md border p-3">
                    <div>
                      <div className="font-medium">{p.name}</div>
                      <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                        <Badge variant="secondary" className="capitalize">{TYPE_LABEL[p.type]}</Badge>
                        <span className="inline-flex items-center gap-1"><MapPin className="h-3 w-3"/>{p.distanceKm} km</span>
                        <span className="inline-flex items-center gap-1"><Clock className="h-3 w-3"/>{p.durationMin} min</span>
                        <span className="inline-flex items-center gap-1"><ShieldCheck className="h-3 w-3"/>{p.safetyScore}% safety</span>
                      </div>
                    </div>
                    <Button onClick={() => addToDay(p)} size="sm">Add</Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Suggestions</CardTitle>
              <CardDescription>Popular picks based on proximity and rating.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {PLACES.filter(p => p.rating >= 4.6).slice(0,6).map((p) => (
                  <Button key={p.id} variant="outline" size="sm" onClick={() => addToDay(p)}>
                    {p.name}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right: Itinerary + map */}
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Itinerary</CardTitle>
              <CardDescription>Build your plan for each day.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {plans.map((d, i) => (
                  <button
                    key={d.id}
                    onClick={() => setDayIndex(i)}
                    className={(i===dayIndex?"bg-brand-ocean text-white border-transparent":"bg-secondary")+" rounded-full border px-3 py-1 text-sm"}
                  >
                    Day {d.id}
                  </button>
                ))}
              </div>

              <div className="mt-4 space-y-2">
                {current.items.length === 0 && (
                  <div className="rounded-md border p-3 text-sm text-muted-foreground">No places added yet. Pick from the left or use suggestions.</div>
                )}
                {current.items.map((p, idx) => (
                  <div key={p.id} className="flex items-center justify-between rounded-md border p-3">
                    <div className="flex items-center gap-3">
                      <Badge variant="secondary">{idx + 1}</Badge>
                      <div>
                        <div className="font-medium">{p.name}</div>
                        <div className="text-xs text-muted-foreground capitalize">{TYPE_LABEL[p.type]} · {p.distanceKm} km · {p.durationMin} min</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" onClick={() => move(idx, -1)}><ChevronUp className="h-4 w-4"/></Button>
                      <Button variant="outline" size="icon" onClick={() => move(idx, 1)}><ChevronDown className="h-4 w-4"/></Button>
                      <Button variant="destructive" size="icon" onClick={() => removeFromDay(idx)}><Trash2 className="h-4 w-4"/></Button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                <Button onClick={optimize} className="inline-flex items-center gap-2"><Wand2 className="h-4 w-4"/> Optimize Route</Button>
                <Button variant="outline" onClick={clearDay}>Clear Day</Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle>Map Preview</CardTitle>
              <CardDescription>Approximate route visualization for the selected day.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="aspect-video rounded-xl bg-gradient-to-br from-brand-ocean/10 via-brand-mint/10 to-brand-sunset/10 p-1">
                <div className="relative h-full w-full rounded-lg bg-background">
                  <svg viewBox="0 0 100 56" className="absolute inset-0 h-full w-full">
                    <defs>
                      <pattern id="gridp" width="8" height="8" patternUnits="userSpaceOnUse">
                        <path d="M 8 0 L 0 0 0 8" fill="none" stroke="hsl(var(--border))" strokeWidth="0.3" opacity="0.5" />
                      </pattern>
                    </defs>
                    <rect width="100" height="56" fill="url(#gridp)" />
                    {current.items.length >= 2 && (
                      <polyline
                        points={current.items.map((p) => `${p.coord.x},${p.coord.y/2}` ).join(" ")}
                        fill="none"
                        stroke="hsl(var(--brand-ocean))"
                        strokeWidth="1.2"
                        strokeLinecap="round"
                        strokeDasharray="3 2"
                      />
                    )}
                    {current.items.map((p, i) => (
                      <g key={p.id}>
                        <circle cx={p.coord.x} cy={p.coord.y/2} r={1.6} fill="hsl(var(--brand-sunset))" />
                        <text x={p.coord.x + 1.8} y={p.coord.y/2 + 0.8} fontSize="2" fill="currentColor">{i + 1}</text>
                      </g>
                    ))}
                  </svg>
                  <div className="absolute bottom-2 left-2 rounded-md border bg-background/80 px-2 py-1 text-xs">
                    {current.items.length} stops · ~{current.items.reduce((a,c)=>a+c.durationMin,0)} min total
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}

function dist(a: {x:number;y:number}, b:{x:number;y:number}) {
  const dx = a.x - b.x; const dy = a.y - b.y; return Math.hypot(dx, dy);
}

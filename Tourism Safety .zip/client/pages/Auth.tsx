import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

export default function Auth() {
  const [mode, setMode] = useState<"signup" | "login">("signup");
  function submit(e: React.FormEvent) {
    e.preventDefault();
    toast.success(mode === "signup" ? "Account created (demo)" : "Logged in (demo)");
  }
  return (
    <section className="container py-12">
      <div className="mx-auto max-w-md">
        <Card>
          <CardHeader>
            <CardTitle>{mode === "signup" ? "Create account" : "Log in"}</CardTitle>
            <CardDescription>
              {mode === "signup" ? "Join SafeTrip to plan safer, smarter journeys." : "Welcome back. Continue your trip planning."}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={submit} className="space-y-4">
              {mode === "signup" && (
                <div>
                  <label className="mb-1 block text-sm">Full name</label>
                  <Input required placeholder="Your name" />
                </div>
              )}
              <div>
                <label className="mb-1 block text-sm">Email</label>
                <Input type="email" required placeholder="you@example.com" />
              </div>
              <div>
                <label className="mb-1 block text-sm">Password</label>
                <Input type="password" required placeholder="••••••••" />
              </div>
              <Button type="submit" className="w-full bg-brand-ocean text-white hover:bg-brand-ocean/90">
                {mode === "signup" ? "Create account" : "Log in"}
              </Button>
            </form>
            <div className="mt-4 text-center text-sm">
              {mode === "signup" ? (
                <button className="underline" onClick={() => setMode("login")}>Have an account? Log in</button>
              ) : (
                <button className="underline" onClick={() => setMode("signup")}>New here? Create account</button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
